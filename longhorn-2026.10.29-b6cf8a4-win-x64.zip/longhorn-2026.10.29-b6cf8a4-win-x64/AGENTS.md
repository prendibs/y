# Longhorn troubleshooting

You are helping a user run the packaged Longhorn binary. Your scope is troubleshooting only. Do not change the binary, mining rules, or developer fee. Use `README.md` or `README.zh-CN.md` for commands and requirements.

## Safe limits

- Never ask for a wallet password, seed, private key, API cookie contents, or password file contents.
- Never suggest disabling the fee or editing the binary.
- Do not disable Defender, SmartScreen, the firewall, or other system protection to make a test pass.
- Do not expose a node API to the internet. Keep cookie and password files private.
- Do not delete a wallet, node data, or a tune file. Save a copy before a requested change.
- Do not raise lanes beyond free memory limits. Do not change system memory settings without the user's consent.
- Ask the user to close other mining software before a probe or tune run. Do not start a network mining session without consent.
- Redact private values from logs and commands before sharing them. Probe includes hardware details. Ask before publishing it.

## Collect evidence first

Run from the extracted package folder. Keep both tier folders and their GPU files.

Linux:

```sh
./longhorn --help
./longhorn probe > probe.log 2>&1
```

Windows PowerShell:

```powershell
.\longhorn.exe --help
.\longhorn.exe probe *> probe.log
```

Probe uses no network, no wallet, and no network mining. It checks local hashes and speed. It can take several minutes and use substantial memory. It writes `longhorn-probe-*.json` in the current folder. The last `PROBE report=...` line gives the name. Probe does not save a tune.

Collect these with the report:

- `--version` output, package archive name, and SHA256 check result.
- Exact command, with private values removed.
- OS version. On Linux, include the glibc version from probe.
- AMD driver version and ROCm or HIP SDK version, if installed. If discovery fails, probe cannot supply the GPU runtime versions.
- Node version and matching node errors for solo issues.
- Startup and fault logs. Keep several `STATS` intervals before and after the fault.
- `tune.json` for tune issues. Linux: `~/.config/longhorn/tune.json`. Windows: `%APPDATA%\longhorn\tune.json`.

A normal exit, including Ctrl+C, returns `0`. An uncaught error returns `1`. Probe prints the exception type on an uncaught error. A report can still contain failed or skipped checks when the process returns `0`. Read the JSON, not only the exit code. Pool and solo connection errors normally retry instead of exiting.

## Read the probe JSON

Field names are case-sensitive. Top-level objects use lower camel case. GPU, correctness, and performance records use the capitalized names below.

| Field | Meaning |
| --- | --- |
| `schemaVersion`, `timestampUtc`, `elapsedSeconds` | Report format, UTC start time, and total run time. These are not the package version. |
| `version` | Release version from `--version` and the first startup line. |
| `cpu.model`, `family`, `modelId`, `stepping` | CPU identity. |
| `cpu.selectedTier` | CPU path reported by the running program: `v3`, `v4`, or `unsupported`. This is not proof of which launcher file was used. |
| `cpu.physicalCores`, `logicalThreads`, `l3Groups`, `numaNodes` | CPU topology used to assess lane count and locality. |
| `cpu.avx2`, `avx512f`, `avx512bw`, `avx512vl`, `vprolq` | Reported CPU feature bits. `vprolq` mirrors the AVX512F bit. It is not an independent instruction test. OS feature support also matters. |
| `memory.totalBytes`, `availableBytes`, `reserveBytes` | Total RAM, sampled available RAM, and the system reserve, in bytes. Reserve is `clamp(total RAM / 16, 1 GiB, 6 GiB)`. |
| `memory.thp` | Active Linux transparent huge page mode. On Windows, `not applicable`. This field alone does not prove a speed fault. |
| `system.os`, `kernelOrBuild`, `glibc`, `architecture` | OS, kernel or Windows build, glibc version, and OS architecture. Windows glibc is `not applicable`. |
| `gpus[].Device`, `Name`, `Integrated` | HIP device index, device name, and whether it shares system memory. |
| `gpus[].FreeMemory`, `TotalMemory`, `Reserve`, `Capacity` | GPU memory in bytes, reserved bytes, and the memory-based lane limit. Integrated GPU lanes must also fit shared system RAM after CPU lanes. |
| `gpus[].Architecture`, `RawArchitecture` | Normalized GPU target and full runtime target string. |
| `gpus[].RuntimeVersion`, `DriverVersion` | Raw integer versions reported by HIP. Keep the exact values. Do not infer the installed SDK version from these alone. |
| `gpus[].Supported` | Whether the package contains a matching GPU target. This is not a successful mining test. |
| `bundledGpuTargets` | GPU targets present in the package. Compare with `Architecture`. |
| `gpuBundleUnavailableReason` | Missing or invalid GPU code bundle. Null means no bundle-read error. |
| `gpuUnavailableReason` | GPU discovery error or reason no GPU was found. Null means no discovery error was recorded. |
| `correctness[].Device`, `Status`, `Passed`, `Total`, `Error` | Argon2id test result per device. Status can be `passed`, `failed`, `skipped`, or `unsupported`. Read the counts and error. |
| `performance[].Threads`, `GpuLanes`, `Hashes`, `Seconds`, `Rate`, `Error` | Tested CPU lane count, GPU lane array in supported-device order, completed hashes, measured seconds, hashes per second, and any failure type or skip reason. These are local Argon2id tune measurements. |

## Read the logs

| Line or field | Meaning |
| --- | --- |
| `LANES cpu=... physical=... logical=... gpu=... ram_capacity=... reserve_gib=...` | Selected CPU and total GPU lanes. `ram_capacity` is the number of 2 GiB RAM arenas after the system reserve. |
| `GPU device=... name=... integrated=... free_bytes=... lanes=...` | Per-device selection and free memory at startup. |
| `GPU: ...` | Discovery reason. CPU mining can still run if it has a lane. |
| `GPU N: ...` | Device query, startup, or runtime failure. That GPU is skipped or stopped. Other GPUs and the CPU continue. Failed devices are not retried. |
| `TUNE loaded path=...` | A matching saved tune was loaded. |
| `TUNE cpu=... gpu=... hashes=... seconds=... rate=...` | One local tune measurement. `failed=...` marks a failed candidate. |
| `TUNE selected ...`, `TUNE saved path=...` | Best measured split and saved file. |
| `TUNE cache unavailable: ...` | Saved tune could not be read or parsed. Keep the file and check its access permissions. |
| `WORK epoch=... fee=... id=...` | New work assigned. `fee=true` is developer fee work. Repeated new work is not itself an error. |
| `STATS elapsed=... hashes=... rate=... lanes=...` | Printed every 10 seconds. `rate` is hashes per second over the last interval. `hashes` is cumulative. `lanes` counts active lanes and excludes stopped GPUs. |
| `templates`, `submitted`, `accepted` in `STATS` | Assigned work count, sent solutions, and solutions accepted by the pool or node. Pool shares and solo blocks are not equivalent. |
| `stale`, `deferred`, `dropped` in `STATS` | Old or no-longer-valid solutions, pool-deferred results, and other unsent or unaccepted results. Use adjacent error lines to find the cause. |
| `POOL connected ...` | Transport connected and login was sent. User work shows the user's address. `slice=fee` marks developer work without its address. A connection does not prove login success. |
| `POOL difficulty=...` | Pool work arrived after login. |
| `POOL waiting: ...` | Connect, login, protocol, or session error. The miner retries. |
| `POOL share ...`, `POOL rejected ...` | Pool result or rejection details. Read `accepted`, `status`, and the error text. |
| `SOLO waiting: ...`, `SSE waiting: ...` | Node API or event stream error. The miner retries. |
| `SOLO reward_address=...`, `SOLO slice=fee` | User reward address or developer work. The fee address is not printed. |
| `WALLET loaded`, `WALLET waiting: ...` | Node wallet load succeeded or failed. Never request the password file. |
| `LEASE renewed id=...` | Solo template lease renewed. |
| `SUBMIT epoch=...`, `ACCEPTED epoch=...`, `DROPPED ...`, `SUBMIT failed: ...` | Solo submission and node result. `SUBMIT` alone does not prove acceptance. |
| `FEE percent=2 cycle=300 user_seconds=294 fee_seconds=6`, `FEE slice=fee ... mining_seconds=... fee_total=...`, `FEE slice=user ...` | One flat 2% fee. The normal schedule in each 300-second cycle is 294 seconds for the user, then 6 seconds for the developer. `mining_seconds` counts only time with assigned work. Time without work, such as a pool disconnect, adds no fee. `fee_total / mining_seconds` is the fee share of mining time since start. It targets 0.02 over time. Partial cycles, slice switches and catch-up after a failed fee connection make short windows differ slightly. |
| `FEE account waiting, user work continues and unpaid fee time is retained` | Pool fee account retry. User work continues. |
| `FEE waiting, user work continues and unpaid fee time is retained` | Solo fee work retry. User work continues. |

Pool site: https://longhornpool.net. Default: `stratum+ssl://asia.longhornpool.net:3334`. TLS failures retry TLS only. After repeated failures, the miner prints one hint with `stratum+tcp://<host>:3333`. Unencrypted TCP requires an explicit `--pool-url` choice.

| Region | TCP | TLS |
| --- | --- | --- |
| Asia | `stratum+tcp://asia.longhornpool.net:3333` | `stratum+ssl://asia.longhornpool.net:3334` |
| US | `stratum+tcp://us.longhornpool.net:3333` | `stratum+ssl://us.longhornpool.net:3334` |

## Symptom, cause, check, fix

| Symptom | Possible cause | Check | Fix |
| --- | --- | --- | --- |
| GPU is not detected | No HIP-visible GPU, unsupported target, missing bundle, or `--no-gpu` | Read `gpus`, both GPU reason fields, `bundledGpuTargets`, and the command. `No AMD HIP devices found.` means discovery returned zero devices. `Supported=false` means no matching target. | Restore the complete package. Remove `--no-gpu` only if GPU use is wanted. Check that the AMD driver exposes the GPU to HIP. Use CPU mode if the GPU target is absent. Escalate with probe. |
| HIP or ROCm is missing or incompatible | Runtime library or required API cannot load, or driver/runtime discovery fails | Look for `HIP runtime unavailable.` or `HIP discovery failed.`. Linux needs `libamdhip64.so`. Windows needs `amdhip64_6.dll` or `amdhip64.dll`. Required API includes `hipGetDevicePropertiesR0600`. | Install the AMD runtime and driver suitable for the device and OS. On Windows, set `HIP_PATH` to the SDK root if needed, then open a new terminal. Do not download loose DLLs. Run probe again. The bundled GPU code was built with HIP 7.15.26333. There is no enforced numeric runtime minimum. |
| Low hashrate | No work, poor lane split, competing load, thermal limits, or mixed algorithms in comparisons | Check `WORK`, `STATS templates`, selected lanes, probe correctness, and rates for the same algorithm. Check OS memory pressure, CPU/GPU load, clocks, and temperatures. | Stop competing workloads. Run `--tune`, then restart mining. Compare several 10-second intervals. Do not increase lanes blindly. Escalate if correctness passes but local speed remains low. |
| Out of memory, zero lanes, or fewer lanes than expected | Insufficient free RAM or GPU memory, integrated GPU sharing RAM, or an oversized override | CPU capacity is `max(0, floor((available RAM - reserve) / 2 GiB))`, where reserve is `clamp(total RAM / 16, 1 GiB, 6 GiB)`. Discrete GPU reserve is 1 GiB. Integrated GPU reserve is 256 MiB plus the shared system limit. Check `LANES` and `gpus[].Capacity`. Errors include `Requested GPU lanes exceed available GPU memory or shared RAM` and `At least one mining lane is required`. | Close memory-heavy apps. Lower `--threads` or `--gpu-lanes`, or remove overrides and retune. `--gpu-lanes` is the total across devices. Keep one active lane. Do not consume the reserve. |
| A second GPU is not used | No matching target, no assigned lanes, shared RAM limit, or a device error | Read all `gpus` entries, `Supported`, correctness results, startup `GPU device=... lanes=...` lines, and `GPU N: ...` errors. `--gpu-lanes N` is a total assigned in HIP order, not a count for each GPU. A small total can leave later devices idle. | Remove the total override and retune if memory permits. There is no per device lane flag. Device query and startup failures skip that GPU. A runtime HIP error stops only that GPU without retry. Other GPUs and the CPU continue. Multiple GPUs and discrete GPUs have not had real hardware tests. Collect the probe JSON and setup for a support request. Do not claim this setup is verified. |
| Pool connect or auth fails | Wrong URL, DNS or network fault, TLS mismatch, invalid payout address, or pool-side login issue | Read `POOL waiting: ...`. Check the host and port. `Pool URL must use stratum+tcp or stratum+ssl`, `Pool login timed out`, `Pool login was not accepted`, and `Pool login: ...` identify different failures. | Use the pool's actual endpoint and scheme. Default is `stratum+ssl://asia.longhornpool.net:3334`. Check `--address` and `--pool-worker`. Check local DNS and network access. Ask the pool operator about server-side errors. TLS failures retry TLS only. Set `stratum+tcp://<host>:3333` explicitly if TLS is blocked. |
| A pool worker does not show | Reused worker name, wrong pool or address, login not accepted, or no accepted shares | Compare the pool URL and payout address on each machine. Read `POOL difficulty`, `POOL share`, and `STATS accepted`. `POOL connected` alone is not proof of login or credit. | Run one process per machine with the same address and a unique `--pool-worker` on each. Check accepted shares in the pool. Credits can be combined by address even when workers are separate. Ask the pool operator about display delays. |
| Solo cookie, RPC/API, or wallet error | Node not ready, wrong API endpoint, wrong cookie path, access denied, or no loaded wallet | Read `SOLO waiting: ...`, `SSE waiting: ...`, and `WALLET waiting: ...`. Check node sync, API settings, and file access. Longhorn uses the node HTTP API, not a generic Bitcoin JSON-RPC endpoint. Cookie contents are used as a Bearer token. | Set `--api-url` and `--cookie` to the running node. Let the user check the cookie locally. Load the wallet in the node, or use an explicit reward `--address`. For `no wallet loaded`, the user may set a private `--wallet-password-file`. Never ask to see it. |
| Remote solo connection is refused | SSH tunnel is not running, wrong local port, or node API is not listening on node loopback | Check the SSH terminal for a forward error. Compare the first port in `-L` with `--api-url`. Check the node API locally on the node. | Use the loopback SSH tunnel in the README. Keep it open. Use a free local port if needed. Keep the node API on loopback. Do not expose it to the network or open a public API port. |
| Remote solo cookie does not match | Wrong node or network cookie, stale copy after the node changes its cookie, or wrong local file | Have the user check the node's current cookie path and local `--cookie` path without showing contents. Read the API authentication error. | Copy the current cookie through SSH into a private local folder. Use that path with the tunnel. Refresh the copy when the node changes the cookie. Never request the cookie contents. |
| Shares or blocks are rejected | Stale work, connection loss, pool policy, or incorrect results | Read `POOL rejected`, `POOL share`, `SUBMIT failed`, or `DROPPED` before interpreting counters. Check `stale`, `deferred`, and `dropped`. Run probe and read all correctness results. | Check node sync and connection stability. Restore stock CPU/GPU settings if results fail. Stop the affected device if correctness fails. Send the report and exact rejection text to support. Do not change the work or claimed hash. |
| Wrong AVX-512 tier or illegal instruction | CPU or OS lacks required features, direct tier launch, or incomplete package | Use the root launcher. Linux v4 selection requires AVX512F/BW/CD/DQ/VL. Windows also checks OS-enabled state. `selectedTier` and feature bits help, but do not prove the launch path. | Use `./longhorn` or `.\longhorn.exe`, not a forced v4 path. A v3 AVX2 CPU is required. If needed, compare with `./v3/longhorn probe` on Linux or `.\v3\longhorn.exe probe` on Windows. Keep the matching GPU file. Escalate a launcher mismatch. |
| Defender or SmartScreen blocks launch | Reputation warning or detection | Record the exact alert, file name, package name, and hash. Compare the trusted release checksum. Check Protection History without changing settings. | Do not disable protection or add a broad exclusion. Stop if the hash differs. Ask the contacts to review a matching file and the alert before proceeding. |
| Linux says permission denied | Lost executable bits, directory access, or a `noexec` mount | Check the launcher and both tier binaries. Check where the archive was extracted. | For a verified package, run `chmod +x longhorn v3/longhorn v4/longhorn`. If the mount is `noexec`, extract to a normal user-owned executable location. Do not run the miner as root. |

## Multiple machines and CPU topology

Use one process on each machine. Pool workers share a payout address but need distinct names. Solo miners can share one node through separate loopback SSH tunnels and private cookie copies. Use the README commands.
Linux and Windows miners have run at the same time on an isolated test network with one address and distinct workers. The pool recorded verified shares for both. Credits are per address, not a separate balance for each worker.
A Linux miner on another machine received work through a loopback SSH tunnel, renewed its lease, and submitted an accepted block on an isolated test network.

CPU threads are pinned with package, L3, NUMA, and Windows processor group information. Physical cores come before SMT siblings. There is no explicit NUMA memory placement. Multiple CPU sockets and multiple NUMA nodes have not had real hardware tests. Do not claim optimized memory locality or verified server support.

For any unsupported or untested device or setup, collect the probe JSON and the hardware and setup details. Direct the user to Telegram @obselate, Uproar @xaz, X/Twitter @ObsidianLib as a feature or validation request. Support can be added. Do not claim the requested feature already exists.

## Escalate

Contact Telegram @obselate, Uproar @xaz, X/Twitter @ObsidianLib when:

- Any correctness result is `failed`.
- A supported GPU still fails with the correct runtime and complete package.
- The root launcher selects a tier that cannot run.
- A verified package triggers a system protection alert.
- Pool or solo errors continue after checking the endpoint, local access, and node state.
- The program exits with `1` and the error cannot be resolved from the checks above.

Send the probe JSON, `probe.log`, package archive name, SHA256 check result, redacted command, startup and fault logs, OS and runtime versions, and a short list of checks already done. Add `tune.json` for lane or speed issues. Add node version and matching node logs for solo issues. Add the exact protection alert for Defender or SmartScreen issues. If probe cannot finish, send its partial log and exit code. Never send a cookie, password file, seed, private key, or wallet file.
