# Longhorn

Longhorn mines Blocknet (BNT) with Argon2id proof of work on CPUs and AMD and NVIDIA GPUs.
Tuned for AMD. Tuned to the max. Use Longhorn Pool or your own Blocknet node.

[简体中文](README.zh-CN.md)

## Requirements

| Item | Requirement |
| --- | --- |
| Linux | x64 Linux with glibc 2.34 or later and Bash. |
| Windows | Windows 10 or 11 x64. |
| CPU | x86-64-v3 CPU with AVX2. The launcher selects the v4 build when AVX-512 is available. No separate .NET install is needed. |
| RAM | Each CPU lane needs 2 GiB of available RAM. Longhorn reserves 1/16 of total RAM, with a minimum of 1 GiB and a maximum of 6 GiB. One CPU lane needs 2 GiB plus this reserve available. |
| GPU, optional | AMD RDNA2, RDNA3, RDNA3.5, or RDNA4 with a matching target in the package, or an NVIDIA CUDA GPU with compute capability 7.5 or newer (Turing, RTX 20 series and later). Each GPU lane needs 2 GiB. A discrete GPU keeps 1 GiB free. An integrated GPU keeps 256 MiB free and also shares the system RAM reserve. |
| Linux GPU runtime | AMD driver and ROCm HIP runtime that provides `libamdhip64.so` and the `hipGetDevicePropertiesR0600` API. NVIDIA GPUs require NVIDIA driver 580 or newer, providing `libcuda.so.1`. |
| Windows GPU runtime | Compatible AMD driver and AMD HIP SDK. Longhorn looks for `amdhip64_6.dll` or `amdhip64.dll` in `%HIP_PATH%\bin` and the normal DLL search path. NVIDIA GPUs require NVIDIA driver 580 or newer, providing `nvcuda.dll`. |

The bundled AMD GPU code was built with HIP 7.15.26333. Longhorn does not enforce a numeric minimum HIP runtime version. Use `probe` to check the installed runtime and GPU code together. NVIDIA GPUs do not need a CUDA toolkit install. CPU mode does not need ROCm, HIP or CUDA.

On Windows, CPU mining uses large pages when available. To enable them, open `secpol.msc` as an administrator, go to **Local Policies > User Rights Assignment > Lock pages in memory**, and add the account that runs Longhorn. Sign out and sign in again. If the right is missing or a large-page allocation fails, Longhorn uses normal pages.

Keep the full extracted folder. Do not move the launcher away from `v3/` and `v4/`. Each tier needs its `longhorn.hipfb` file for AMD GPU use and its `longhorn.cudafb` file for NVIDIA GPU use.

## Quick start

Replace `YOUR_BNT_ADDRESS` with your payout address. Run commands from the extracted package folder. Stop with Ctrl+C.

### Linux pool

```sh
./longhorn --mode pool --address YOUR_BNT_ADDRESS
```

The default pool is `stratum+ssl://asia.longhornpool.net:3334`. Pool site: https://longhornpool.net. TLS failures retry TLS only. After repeated failures, the miner prints an explicit TCP URL. Unencrypted TCP requires setting `--pool-url stratum+tcp://<host>:3333`.

| Region | TCP | TLS |
| --- | --- | --- |
| Asia | `stratum+tcp://asia.longhornpool.net:3333` | `stratum+ssl://asia.longhornpool.net:3334` |
| US | `stratum+tcp://us.longhornpool.net:3333` | `stratum+ssl://us.longhornpool.net:3334` |

To choose the US Longhorn endpoint with TLS and a worker name:

```sh
./longhorn --mode pool --address YOUR_BNT_ADDRESS --pool-url stratum+ssl://us.longhornpool.net:3334 --pool-worker rig1
```

### Windows pool, PowerShell

```powershell
.\longhorn.exe --mode pool --address YOUR_BNT_ADDRESS
```

```powershell
.\longhorn.exe --mode pool --address YOUR_BNT_ADDRESS --pool-worker rig1
```

### Linux solo

Start and sync your Blocknet node. Enable its API. Load your wallet in the node, or supply a payout address. Set the API URL and the path to that node's API cookie:

```sh
./longhorn --mode solo --api-url http://127.0.0.1:8332 --cookie "$HOME/.config/bnt/data/mainnet/api.cookie" --address YOUR_BNT_ADDRESS
```

### Windows solo, PowerShell

Set the cookie path to the actual cookie file used by your node:

```powershell
.\longhorn.exe --mode solo --api-url http://127.0.0.1:8332 --cookie "C:\path\to\api.cookie" --address YOUR_BNT_ADDRESS
```

In solo mode, omit `--address` to use the node wallet's reward address. If the node reports `no wallet loaded`, you can use `--wallet-password-file` with a local text file that contains the wallet password. Longhorn uses it to load the node wallet. Keep this file private. Never send it to support.

## Commands and flags

`probe` checks hardware, hash correctness, and local speed. `bench` runs a local benchmark. Neither uses the network or a wallet, and neither submits mining work.

| Flag | Meaning and default |
| --- | --- |
| `--help` | Print help and exit. |
| `--version` | Print the release version and exit. |
| `--mode solo\|pool` | Required for mining. Choose a node or a pool. |
| `--api-url URL` | Solo node API. Default `http://127.0.0.1:8332`. |
| `--cookie PATH` | Solo API cookie. Default `$HOME/.config/bnt/data/mainnet/api.cookie` on Linux and `%USERPROFILE%\.config\bnt\data\mainnet\api.cookie` on Windows. |
| `--wallet-password-file PATH` | Optional local password file for loading the solo node wallet. No default. |
| `--address ADDRESS` | Required for pool mining. Optional solo reward address. |
| `--pool-url URL` | Choose an Asia or US Longhorn endpoint with TCP or TLS. Default `stratum+ssl://asia.longhornpool.net:3334`. |
| `--pool-worker NAME` | Pool worker name. Default is the computer name. |
| `--threads N` | Set CPU lanes. `0` disables CPU mining. Default is the smaller of physical core count and RAM capacity, or the saved tune. |
| `--depth 1|2` | Set CPU arenas per thread. Each arena needs 2 GiB. Skips automatic tuning. |
| `--gpu-lanes N` | Set the total GPU lanes across all supported devices, not per device. `0` disables GPU mining. Default fits available memory, or uses the saved tune. |
| `--no-gpu` | Skip GPU discovery and use CPU only. |
| `--tune` | Measure lane and CPU depth combinations, save the fastest result, and exit. Does not start network mining. |
| `--seconds N` | Time per `bench` round. Default `20`. Bench has one warmup and two measured rounds. Does not change `probe` or `--tune` time. |

## Tune and lane limits

```sh
./longhorn --tune
./longhorn --mode pool --address YOUR_BNT_ADDRESS --threads 2 --gpu-lanes 1
./longhorn --mode pool --address YOUR_BNT_ADDRESS --no-gpu
```

```powershell
.\longhorn.exe --tune
.\longhorn.exe --mode pool --address YOUR_BNT_ADDRESS --threads 2 --gpu-lanes 1
.\longhorn.exe --mode pool --address YOUR_BNT_ADDRESS --no-gpu
```

On first start, Longhorn tunes lanes and CPU depth, saves the result, then mines. It tunes again when the kernel changes. This can take several minutes. Close memory-heavy apps and other mining software first.

- Linux tune file: `~/.config/longhorn/tune.json`.
- Windows tune file: `%APPDATA%\longhorn\tune.json`.
- A matching tune loads on later runs. `TUNE loaded path=...` confirms this.
- Explicit `--threads`, `--gpu-lanes` or `--depth` values skip automatic tuning and take priority. They must fit current free memory. GPU lanes are assigned in device order.
- CPU and integrated GPU lanes share system RAM. Keep at least one CPU or GPU lane active.
- Run `--tune` again after hardware or memory changes. Probe does not replace the saved tune.

## Multiple machines and devices

Run one Longhorn process on each machine. For pool mining, use the same payout address and a different worker name on each machine.

Linux machine:

```sh
./longhorn --mode pool --address YOUR_BNT_ADDRESS --pool-worker rig1
```

Windows machine, PowerShell:

```powershell
.\longhorn.exe --mode pool --address YOUR_BNT_ADDRESS --pool-worker rig2
```

Check that the pool lists both workers and accepts shares from each. A connection alone does not prove credit.

For solo mining from several machines, keep the node API on the node's loopback address. Do not expose it to the network. Each miner needs SSH access to the node and a private copy of its current API cookie. Replace `NODE_LOGIN` with your SSH login and `NODE_COOKIE_PATH` with the cookie path on the node.

On each Linux miner, copy the cookie into a private folder:

```sh
umask 077
scp NODE_LOGIN:NODE_COOKIE_PATH ./api.cookie
```

Keep this tunnel open in one terminal on each miner:

```sh
ssh -N -o ExitOnForwardFailure=yes -L 127.0.0.1:8332:127.0.0.1:8332 NODE_LOGIN
```

In another terminal:

```sh
./longhorn --mode solo --api-url http://127.0.0.1:8332 --cookie ./api.cookie --address YOUR_BNT_ADDRESS
```

Windows can use the same `scp` and `ssh` commands with Windows OpenSSH. Store the cookie in a folder that only your account can read. Start `.\longhorn.exe` with the same solo flags. If local port 8332 is in use, change the first port in `-L` and the port in `--api-url`. If the node changes its cookie, copy the new cookie. Never send it to support.

| Device setup | Behavior and limits |
| --- | --- |
| Multiple AMD and NVIDIA GPUs | Longhorn discovers HIP and CUDA devices. It uses devices with compatible bundled GPU code and at least one assigned lane at the same time. Automatic lanes fit each device's free memory. CPU and integrated GPU lanes share the system RAM budget. Each discrete GPU keeps 1 GiB free. |
| GPU lane control | `--gpu-lanes N` is a total, not a limit for each GPU. Lanes go to devices in discovery order. A small total can leave later GPUs idle. There is no per device lane flag. Read each startup `GPU device=... lanes=...` line. |
| GPU faults | A device query or startup failure is logged once and that GPU is skipped. A HIP or CUDA error during mining stops only that GPU and removes its lanes from active totals. Other GPUs and the CPU keep mining. Failed devices are not retried. |
| Multiple CPU sockets | CPU threads use package, L3, and NUMA topology. Physical cores come before SMT siblings. Windows processor groups are handled. There is no explicit NUMA memory placement. Memory locality is not yet optimized. |

| Tested setup | Result |
| --- | --- |
| Two machines in one pool | Linux and Windows mined at the same time with one address and distinct workers on an isolated test network. The pool recorded verified shares for both. |
| Remote solo through SSH | A Linux miner on another machine received work, renewed its lease, and submitted an accepted block on an isolated test network. |
| Linux CPU probe | 8 physical cores, 16 logical threads, 2 L3 groups, 1 NUMA node. CPU hash checks passed. |
| Windows VM CPU probe | 4 physical cores, 4 logical threads, 1 L3 group, 1 NUMA node. CPU hash checks passed. |
| AMD gfx1151 integrated GPU | Tested on one device. |
| Multiple GPUs, discrete GPUs, multiple CPU sockets, multiple NUMA nodes | Code paths exist, but no real hardware test. Do not treat this as verified support. |

For an unsupported or untested setup, request support or a validation run from Telegram @obselate, Uproar @xaz, X/Twitter @ObsidianLib. Send the probe JSON and your hardware and setup details. Support can be added. Do not assume it is already available.

## Probe and support

```sh
./longhorn probe > probe.log 2>&1
```

```powershell
.\longhorn.exe probe *> probe.log
```

Probe runs local tests only. It uses no network, no wallet, and no network mining. It can use much of the available memory. Let it finish. The last `PROBE report=...` line names the `longhorn-probe-*.json` file in the current folder.

For help, send:

- The generated JSON file and `probe.log`.
- The `--version` output, package file name, and SHA256 result.
- Your command with private values removed.
- Mining logs from startup through the fault. Include nearby `LANES`, `WORK`, `STATS`, and error lines.
- OS version, AMD driver version, and ROCm or HIP SDK version, if installed.
- For solo issues, the node version and its matching error lines.
- For tuning issues, `tune.json`, if present.

Remove cookie contents, wallet passwords, seeds, private keys, and private API credentials. You may also hide payout addresses and local user names. `AGENTS.md` contains troubleshooting steps for an AI assistant.

## Fee

One flat 2% developer fee applies to pool and solo mining. Each 300-second cycle starts with 294 seconds for the user, then 6 seconds for the developer. User connections show your address. `POOL connected ... slice=fee`, `fee=true` and `FEE slice=fee` mark developer fee work without showing its address. `FEE slice=user` marks user mining. A failed fee connection does not erase unpaid fee time.

## Verify SHA256SUMS

Get the archive and its published `SHA256SUMS` from a trusted release source. Check the archive before extraction. Then check the `SHA256SUMS` inside the extracted folder.

Linux, in the folder that contains the files listed in the checksum file:

```sh
sha256sum -c SHA256SUMS
```

Windows PowerShell, in the folder that contains the files listed in the checksum file:

```powershell
Get-Content .\SHA256SUMS | ForEach-Object {
    $expected, $file = $_ -split '\s+', 2
    $file = $file.TrimStart('*')
    $actual = (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash
    if ($actual -ne $expected) {
        throw "SHA256 mismatch: $file"
    }
    Write-Host "OK $file"
}
```

Do not run a package with a mismatched checksum. A checksum from the same untrusted source does not prove who published the file.

## Contacts

Telegram @obselate, Uproar @xaz, X/Twitter @ObsidianLib
