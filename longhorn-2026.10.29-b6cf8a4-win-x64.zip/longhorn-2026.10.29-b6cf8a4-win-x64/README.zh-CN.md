# Longhorn

Longhorn 使用 CPU、AMD GPU 和 NVIDIA GPU 挖掘 Blocknet（BNT），采用 Argon2id 工作量证明。
为 AMD 调优，性能拉满。支持 Longhorn 矿池，也支持连接自己的 Blocknet 节点。

[English](README.md)

## 运行要求

| 项目 | 要求 |
| --- | --- |
| Linux | x64 Linux，glibc 2.34 或更新版本，已安装 Bash。 |
| Windows | Windows 10 或 11 x64。 |
| CPU | 支持 AVX2 的 x86-64-v3 CPU。启动器会在支持 AVX-512 时自动选择 v4 版本。无需另装 .NET。 |
| 内存 | 每条 CPU 通道需要 2 GiB 可用内存。Longhorn 保留总内存的 1/16，最少 1 GiB，最多 6 GiB。运行一条 CPU 通道需要至少 2 GiB 加上此保留量的可用内存。 |
| GPU，可选 | AMD RDNA2、RDNA3、RDNA3.5 或 RDNA4，且安装包中包含对应的 GPU 目标；或计算能力为 7.5 及以上的 NVIDIA CUDA GPU（Turing 架构、RTX 20 系列及更新型号）。每条 GPU 通道需要 2 GiB。独显保留 1 GiB 显存。核显保留 256 MiB，并受系统内存保留量的限制。 |
| Linux GPU 运行库 | AMD 驱动及 ROCm HIP 运行库，需提供 `libamdhip64.so` 和 `hipGetDevicePropertiesR0600` 接口。NVIDIA GPU 需要 580 或更新版本的 NVIDIA 驱动，提供 `libcuda.so.1`。 |
| Windows GPU 运行库 | 兼容的 AMD 驱动及 AMD HIP SDK。Longhorn 会在 `%HIP_PATH%\bin` 和常规 DLL 搜索路径中查找 `amdhip64_6.dll` 或 `amdhip64.dll`。NVIDIA GPU 需要 580 或更新版本的 NVIDIA 驱动，提供 `nvcuda.dll`。 |

随包提供的 AMD GPU 程序使用 HIP 7.15.26333 构建。Longhorn 不按版本号强制限制 HIP 运行库的最低版本。请运行 `probe`，确认已安装的运行库能与随包 GPU 程序配合使用。NVIDIA GPU 无需安装 CUDA 工具包。只用 CPU 时不需要 ROCm、HIP 或 CUDA。

Windows 下，CPU 挖矿会在可用时使用大页。启用方法：以管理员身份打开 `secpol.msc`，进入“本地策略 > 用户权限分配 > 锁定内存中的页面”，添加运行 Longhorn 的账户，然后注销并重新登录。没有此权限或大页分配失败时，Longhorn 使用普通页。

请保留解压后的完整目录。不要把启动器移出含有 `v3/`、`v4/` 的目录。使用 AMD GPU 时，各版本目录内的 `longhorn.hipfb` 都必须保留。使用 NVIDIA GPU 时，必须保留 `longhorn.cudafb`。

## 快速开始

将 `YOUR_BNT_ADDRESS` 替换为你的收款地址。在解压后的安装包目录中运行命令。按 Ctrl+C 停止。

### Linux 矿池模式

```sh
./longhorn --mode pool --address YOUR_BNT_ADDRESS
```

默认矿池为 `stratum+ssl://asia.longhornpool.net:3334`。矿池网站：https://longhornpool.net。TLS 失败后只重试 TLS。连续失败后，矿机会显示明确的 TCP 地址。使用未加密的 TCP 必须手动设置 `--pool-url stratum+tcp://<host>:3333`。

| 地区 | TCP | TLS |
| --- | --- | --- |
| 亚洲 | `stratum+tcp://asia.longhornpool.net:3333` | `stratum+ssl://asia.longhornpool.net:3334` |
| 美国 | `stratum+tcp://us.longhornpool.net:3333` | `stratum+ssl://us.longhornpool.net:3334` |

选择美国 Longhorn 矿池的 TLS 端点并设置矿机名：

```sh
./longhorn --mode pool --address YOUR_BNT_ADDRESS --pool-url stratum+ssl://us.longhornpool.net:3334 --pool-worker rig1
```

### Windows 矿池模式，PowerShell

```powershell
.\longhorn.exe --mode pool --address YOUR_BNT_ADDRESS
```

```powershell
.\longhorn.exe --mode pool --address YOUR_BNT_ADDRESS --pool-worker rig1
```

### Linux 单挖模式

先启动并同步 Blocknet 节点，开启节点 API。在节点中加载钱包，或指定收款地址。设置 API 地址及该节点的 API cookie 文件路径：

```sh
./longhorn --mode solo --api-url http://127.0.0.1:8332 --cookie "$HOME/.config/bnt/data/mainnet/api.cookie" --address YOUR_BNT_ADDRESS
```

### Windows 单挖模式，PowerShell

将 cookie 路径改为你的节点实际使用的文件路径：

```powershell
.\longhorn.exe --mode solo --api-url http://127.0.0.1:8332 --cookie "C:\path\to\api.cookie" --address YOUR_BNT_ADDRESS
```

单挖时，不填 `--address` 就会使用节点钱包的奖励地址。如果节点提示 `no wallet loaded`，可用 `--wallet-password-file` 指向本地文本文件，文件内只放钱包密码。Longhorn 会用它加载节点钱包。请妥善保管此文件，切勿发给客服。

## 子命令与参数

`probe` 检查硬件、哈希正确性和本地速度。`bench` 运行本地性能测试。两者都不联网、不访问钱包，也不提交挖矿结果。

| 参数 | 用途与默认值 |
| --- | --- |
| `--help` | 显示帮助并退出。 |
| `--version` | 显示发布版本并退出。 |
| `--mode solo\|pool` | 挖矿时必填。`solo` 连接节点，`pool` 连接矿池。 |
| `--api-url URL` | 单挖节点 API 地址。默认 `http://127.0.0.1:8332`。 |
| `--cookie PATH` | 单挖 API cookie 路径。Linux 默认 `$HOME/.config/bnt/data/mainnet/api.cookie`，Windows 默认 `%USERPROFILE%\.config\bnt\data\mainnet\api.cookie`。 |
| `--wallet-password-file PATH` | 可选的本地密码文件，用于加载单挖节点的钱包。无默认值。 |
| `--address ADDRESS` | 矿池挖矿必填。单挖时可用于指定奖励地址。 |
| `--pool-url URL` | 选择亚洲或美国 Longhorn 矿池的 TCP 或 TLS 端点。默认 `stratum+ssl://asia.longhornpool.net:3334`。 |
| `--pool-worker NAME` | 矿机名。默认使用计算机名。 |
| `--threads N` | 设置 CPU 通道数。`0` 表示停用 CPU 挖矿。默认取物理核心数与内存可容纳通道数中的较小值，或使用已保存的调优结果。 |
| `--depth 1|2` | 设置每个 CPU 线程的内存区数量，每个需要 2 GiB。跳过自动调优。 |
| `--gpu-lanes N` | 设置所有受支持 GPU 的通道总数，不是每张卡的数量。`0` 表示停用 GPU 挖矿。默认按可用内存分配，或使用已保存的调优结果。 |
| `--no-gpu` | 跳过 GPU 检测，只用 CPU。 |
| `--tune` | 测量通道和 CPU 深度组合，保存最快的结果后退出。不会开始联网挖矿。 |
| `--seconds N` | `bench` 每轮的秒数。默认 `20`。共一轮预热和两轮计时测试。不改变 `probe` 或 `--tune` 的时长。 |

## 调优与通道限制

```sh
./longhorn --tune
./longhorn --mode pool --address YOUR_BNT_ADDRESS --threads 2 --gpu-lanes 1
./longhorn --mode pool --address YOUR_BNT_ADDRESS --no-gpu
```

```powershell
.\longhorn.exe --tune
.\longhorn.exe --mode pool --address YOUR_BNT_ADDRESS --threads 2 --gpu-lanes 1
.\longhorn.exe --mode pool --address YOUR_BNT_ADDRESS --no-gpu
```

首次启动时，Longhorn 会自动调优通道和 CPU 深度，保存结果后开始挖矿。内核更新后会重新调优。这可能需要几分钟。请先关闭占用大量内存的应用和其他挖矿软件。

- Linux 调优文件：`~/.config/longhorn/tune.json`。
- Windows 调优文件：`%APPDATA%\longhorn\tune.json`。
- 后续启动时会加载匹配的调优结果。日志中的 `TUNE loaded path=...` 表示已加载。
- 手动指定 `--threads`、`--gpu-lanes` 或 `--depth` 会跳过自动调优，并优先使用这些值。不能超过当前可用内存。GPU 通道按设备顺序分配。
- CPU 和核显通道共用系统内存。至少要保留一条 CPU 或 GPU 通道。
- 更换硬件或调整内存后，请重新运行 `--tune`。Probe 不会覆盖已保存的调优结果。

## 多台机器与多个设备

每台机器运行一个 Longhorn 进程。矿池模式下，各台机器使用相同的收款地址，并设置不同的矿机名。

Linux 机器：

```sh
./longhorn --mode pool --address YOUR_BNT_ADDRESS --pool-worker rig1
```

Windows 机器，PowerShell：

```powershell
.\longhorn.exe --mode pool --address YOUR_BNT_ADDRESS --pool-worker rig2
```

确认矿池同时显示两台矿机，并接受各自提交的份额。仅连接成功不代表已经计入收益。

多台机器连接同一个节点单挖时，节点 API 只监听节点本机的回环地址，不要向网络开放。每台矿机都需要通过 SSH 访问节点，并单独保存当前 API cookie 的私有副本。将 `NODE_LOGIN` 替换为 SSH 登录目标，将 `NODE_COOKIE_PATH` 替换为节点上的 cookie 路径。

在每台 Linux 矿机的私有目录中复制 cookie：

```sh
umask 077
scp NODE_LOGIN:NODE_COOKIE_PATH ./api.cookie
```

在每台矿机的一个终端中保持隧道运行：

```sh
ssh -N -o ExitOnForwardFailure=yes -L 127.0.0.1:8332:127.0.0.1:8332 NODE_LOGIN
```

另开一个终端：

```sh
./longhorn --mode solo --api-url http://127.0.0.1:8332 --cookie ./api.cookie --address YOUR_BNT_ADDRESS
```

Windows 可使用 Windows OpenSSH 运行相同的 `scp` 和 `ssh` 命令。将 cookie 保存在只有当前账户能读取的目录中，然后用相同的单挖参数启动 `.\longhorn.exe`。如果本地 8332 端口已被占用，同时修改 `-L` 中的第一个端口和 `--api-url` 中的端口。节点更换 cookie 后，需要重新复制。切勿把 cookie 发给客服。

| 设备配置 | 行为与限制 |
| --- | --- |
| 多张 AMD 和 NVIDIA GPU | Longhorn 枚举 HIP 和 CUDA 设备，同时使用随包 GPU 程序兼容且分配到至少一条通道的设备。默认按各设备的可用内存分配通道。CPU 与核显共用系统内存预算。每张独显保留 1 GiB 显存。 |
| GPU 通道控制 | `--gpu-lanes N` 是所有 GPU 的通道总数，不是每张卡的上限。通道按设备发现顺序分配，总数较小时，后面的 GPU 可能闲置。没有按设备单独设置通道的参数。请查看启动日志中每条 `GPU device=... lanes=...`。 |
| GPU 故障 | 单个设备的查询或初始化失败会记录一条日志并跳过该 GPU。挖矿期间的 HIP 或 CUDA 错误只停止故障 GPU，其通道不再计入活动总数。其他 GPU 和 CPU 继续挖矿。不会自动重试故障设备。 |
| 多 CPU 插槽 | CPU 线程调度考虑处理器封装、L3 缓存和 NUMA 拓扑，优先使用物理核心，再使用 SMT 同胞线程。支持 Windows 处理器组。尚未显式指定 NUMA 内存位置，内存局部性还未优化。 |

| 已测试配置 | 结果 |
| --- | --- |
| 两台机器连接同一矿池 | Linux 和 Windows 在隔离测试网络中同时挖矿，使用相同地址和不同矿机名。矿池记录了两者通过验证的份额。 |
| 通过 SSH 远程单挖 | 另一台机器上的 Linux 矿工在隔离测试网络中取得任务、续租模板，并提交了节点接受的区块。 |
| Linux CPU probe | 8 个物理核心、16 个逻辑线程、2 个 L3 缓存组、1 个 NUMA 节点。CPU 哈希校验通过。 |
| Windows 虚拟机 CPU probe | 4 个物理核心、4 个逻辑线程、1 个 L3 缓存组、1 个 NUMA 节点。CPU 哈希校验通过。 |
| AMD gfx1151 核显 | 已测试单个设备。 |
| 多 GPU、独显、多 CPU 插槽、多 NUMA 节点 | 代码包含相应路径，但尚未经过实机测试，不能视为已经验证的支持。 |

如果你的配置尚不支持或尚未测试，可以联系 Telegram @obselate、Uproar @xaz、X（Twitter）@ObsidianLib，申请增加支持或安排验证。请提供 probe JSON、硬件型号和部署方式。相关支持可以添加，但不要把待验证的功能当作已有功能。

## 检测与求助

```sh
./longhorn probe > probe.log 2>&1
```

```powershell
.\longhorn.exe probe *> probe.log
```

Probe 只在本地测试，不联网、不访问钱包，也不参与网络挖矿。它可能占用较多可用内存，请等待完成。最后一条 `PROBE report=...` 会给出报告文件名。`longhorn-probe-*.json` 保存在当前目录。

求助时请提供：

- 生成的 JSON 文件和 `probe.log`。
- `--version` 输出、安装包文件名及 SHA256 校验结果。
- 运行命令，先去掉隐私内容。
- 从启动到出错的挖矿日志，包括附近的 `LANES`、`WORK`、`STATS` 和错误行。
- 系统版本、AMD 驱动版本，以及已安装的 ROCm 或 HIP SDK 版本。
- 单挖问题还需提供节点版本及对应的节点错误日志。
- 调优问题还需提供 `tune.json`，如果该文件存在。

不要发送 cookie 内容、钱包密码、助记词、私钥或私有 API 凭据。也可以隐去收款地址和本地用户名。`AGENTS.md` 为 AI 助手提供了排查步骤。

## 开发者费用

矿池和单挖统一收取 2% 开发者费用。每个 300 秒周期先为用户挖矿 294 秒，再为开发者挖矿 6 秒。用户连接显示你的地址。`POOL connected ... slice=fee`、`fee=true` 和 `FEE slice=fee` 表示开发者任务，不显示开发者地址。`FEE slice=user` 表示用户任务。开发者连接失败时，未完成的费用时间仍会保留。

## 验证 SHA256SUMS

请从可信的发布渠道获取压缩包及对应的 `SHA256SUMS`。解压前先校验压缩包，再校验解压目录内的 `SHA256SUMS`。

Linux，在包含校验文件所列文件的目录中运行：

```sh
sha256sum -c SHA256SUMS
```

Windows PowerShell，在包含校验文件所列文件的目录中运行：

```powershell
Get-Content .\SHA256SUMS | ForEach-Object {
    $expected, $file = $_ -split '\s+', 2
    $file = $file.TrimStart('*')
    $actual = (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash
    if ($actual -ne $expected) {
        throw "SHA256 mismatch: $file"
    }
    Write-Host "OK $file"
}
```

校验不一致时不要运行。同一不可信来源提供的校验值，不能证明文件由谁发布。

## 联系方式

Telegram @obselate、Uproar @xaz、X（Twitter）@ObsidianLib
