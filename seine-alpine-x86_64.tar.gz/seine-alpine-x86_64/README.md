# Seine for Alpine Linux x86-64

Portable CPU-only build from upstream master at commit
`c99b4302c1f5eda9e6a091fa643f0c32d4ed5a45` (package version 0.2.45).
Built on 31 October 2026 for `x86_64-unknown-linux-musl`, using Rust 1.93.0,
the upstream lockfile and release profile, and static musl linking.

## Run

From the extracted directory, as your ordinary user:

```sh
sha256sum -c SHA256SUMS
./seine --version
./seine
```

No `apk add`, root access, glibc, `gcompat`, or shared-library installation is
required. The executable uses the CPU only; NVIDIA, AMD and Metal GPU backends
are not included. CPU kernels are selected at runtime; this binary was not
compiled with `target-cpu=native`. A mining worker needs approximately 2 GiB of
RAM plus overhead.

For a short offline check:

```sh
./seine --bench --backend cpu --threads 1 --bench-secs 3 --bench-rounds 1
```

## Alpine update guard

This build includes the small source change in `alpine-update.patch`:
automatic binary replacement is disabled on musl, and `--self-update` exits
with an explanatory error before network access. Upstream's published Linux
archives use glibc, so installing those would break the Alpine executable.
Build a new musl version to upgrade. Release notifications remain available;
`--disable-update-check` turns them off.

## Rebuild

From this directory, on an x86-64 Docker host with BuildKit:

```sh
docker build --platform linux/amd64 --output type=local,dest=rebuilt .
./rebuilt/seine --version
```

The Dockerfile pins the source commit and Rust image. Alpine package repositories
are live, so future rebuilds can pick up newer compiler package revisions.
This is a custom build, not an upstream-signed release.

See `VERIFICATION.md` for the tests performed and their limits. The upstream
license and privacy notice are included unchanged.
