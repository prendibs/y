# Verification

Verified on 31 October 2026 (Asia/Jakarta).

## Build identity

- Source: https://github.com/zpalmtree/seine
- Master commit: `c99b4302c1f5eda9e6a091fa643f0c32d4ed5a45`
- Display version: `seine 0.2.45-alpine-c99b430`
- Rust: `rustc 1.93.0 (254b59607 2026-01-19)`
- Target: `x86_64-unknown-linux-musl`
- Features: CPU only (`--no-default-features`)
- Profile: release, upstream fat LTO and codegen-units=1
- Additional Rust flags: `-C target-feature=+crt-static`
- Build image: `rust:1.93.0-alpine3.22` (Alpine 3.22.3)
- Build image digest: `sha256:efc08a6cc70a6ad8bdcf24176e3e0bdbbc7b984e7471fabf78b90de33b136f51`
- Runtime test image: `alpine:3.22.7`
- Runtime image digest: `sha256:2e0b81d60597f449baa56dc25d355367869d2dca4cd57e866f1e2b52af3eb55f`
- Executable SHA-256: `a29498f5807822e68314d7dfc74b750cc756a2baf768c50b38813a90d11a66d5`
- Executable size: 8,493,824 bytes (stripped)

The only source changes are the musl update guard and its regression test,
included in `alpine-update.patch`. Rustfmt was run on the two edited files.

## Checks passed

- ELF inspection: x86-64 static PIE; no `PT_INTERP`, no `DT_NEEDED` entries.
- Clean Alpine 3.22.7 container, UID/GID 10001:10001, no gcompat, networking
  disabled: `--version`, `--help`, and a single-worker offline Argon2id benchmark
  all succeeded. The benchmark initialized a full 2 GiB CPU arena and completed
  8 hashes (7 inside the measurement window).
- `--self-update` rejected the operation with the expected musl-specific message,
  before network access, in that same network-disabled runtime.
- 20 upstream CPU kernel unit/integration tests passed on the musl target:
  reference parity, supported kernel selection, streaming reuse/boundaries,
  cancellation, and Blake2b behavior.
- 6 updater unit tests passed on the musl target, including the added rejection
  regression test and existing signature, checksum, and archive tests.
- Package checksums and extracted executable startup were checked as a non-root
  user in Alpine 3.22.7.

The runtime tests ran in Docker under WSL2 on an AMD Ryzen 7 7800X3D. The short
benchmark was a functional check, not a performance comparison. No live pool
mining or GPU functionality was tested; GPU backends are not included. The full
application test suite was not run.
