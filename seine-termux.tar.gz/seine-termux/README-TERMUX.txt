Seine v0.2.45 for Android ARM64 / Termux

Target: aarch64-linux-android, Android 7.0 (API 24) or newer.
CPU architecture: ARM64 / aarch64, suitable for Snapdragon 835.
CPU support only. The phone's Adreno GPU is not supported by this build.

Installation
------------
Save seine-termux.tar.gz in the phone's Downloads folder.
Open a native Termux session and run:

  termux-setup-storage

Allow storage access, then run:

  cd ~
  tar -xzf ~/storage/downloads/seine-termux.tar.gz
  cd ~/seine-termux
  ./seine --version

The expected version is: seine v0.2.45

These are ordinary Termux commands, without a notebook exclamation mark.
Extract into Termux's home directory as shown: Android's shared storage
normally does not permit executing downloaded programs directly.

When starting mining, supply your own --address and --pool-url and use
--ui plain --backend cpu --threads 1. Each worker needs about 2 GiB RAM plus
program overhead. Android and other apps need additional memory. The phone's
eight CPU cores do not imply that eight workers fit in memory.

Ctrl+C stops the process. Termux's extra-key row provides a Ctrl key.
Upstream flag documentation:
https://github.com/zpalmtree/seine/blob/v0.2.45/docs/MINER_FLAGS.md

Updates
-------
Use manually rebuilt Android binaries for future updates. The v0.2.45
self-updater has no Android release target, so --self-update and --auto-update
cannot install a native Android release. Automatic updating is off by default.

Build and verification
----------------------
Built from unmodified v0.2.45 source using Rust 1.93.0 and Android NDK r27c.
The binary is ARM64 and uses /system/bin/linker64 with Android's Bionic
libraries. No glibc installation or root access is required.

Compilation and static binary/library checks passed. This build has not been
executed on a physical Android device; runtime operation remains unverified.
BUILD-INFO.txt records the build settings. The upstream license, README and
privacy policy are included. SHA256SUMS.txt covers the extracted files.
