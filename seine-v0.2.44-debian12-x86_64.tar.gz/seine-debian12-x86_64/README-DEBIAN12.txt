Seine v0.2.44 — Debian 12 / Linux x86_64 build

Built from unmodified upstream source:
https://github.com/zpalmtree/seine/tree/v0.2.44
Commit: 752f6679d0656eb45404bf867a72a3c475c59cdf

This is a locally rebuilt binary, not the upstream release download.
Built and verified on Debian 12 with glibc 2.36. The highest required
GLIBC symbol version is GLIBC_2.34. No glibc replacement is needed.

Notebook usage
--------------
Upload seine-v0.2.44-debian12-x86_64.tar.gz into your notebook directory.
Run these in a Python/IPython notebook cell:

!tar -xzf seine-v0.2.44-debian12-x86_64.tar.gz
!./seine-debian12-x86_64/seine --version

For a notebook, use --ui plain and supply --address and --pool-url
explicitly when starting Seine. See the upstream configuration guide:
https://github.com/zpalmtree/seine/blob/v0.2.44/docs/guides/configuration.md

Features and verification
-------------------------
CPU and NVIDIA support are included. NVIDIA use requires compatible NVIDIA
drivers and the NVRTC runtime, as with upstream's Linux release. GPU runtime
operation was not tested in this build environment.

Startup, help, dynamic library resolution, an offline CPU backend smoke run,
and full 2 GiB reference-hash checks for all 12 supported x86 CPU kernels passed.
The short smoke run was a functional check, not a performance measurement.

The build uses upstream's pinned Rust 1.93.0 and Cargo.lock. No native-CPU
compiler flags were added. See BUILD-INFO.txt for provenance and checks.

Upstream licensing, privacy policy and README accompany this binary.
SHA256SUMS.txt contains checksums for the extracted files.
