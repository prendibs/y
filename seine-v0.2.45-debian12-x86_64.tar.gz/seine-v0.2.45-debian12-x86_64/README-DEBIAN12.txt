Seine v0.2.45 for Debian 12 / Linux x86_64

Built from unmodified upstream source:
https://github.com/zpalmtree/seine/tree/v0.2.45
Commit: 2c40c7b725f4ff1464205c09763149efe895e3e7

This is a local rebuild for Debian 12 with glibc 2.36.
It includes the upstream default CPU and NVIDIA support.

Notebook installation
---------------------
Upload seine-v0.2.45-debian12-x86_64.tar.gz to your notebook directory.
Run these commands in a Python/IPython notebook cell:

!tar -xzf seine-v0.2.45-debian12-x86_64.tar.gz
!./seine-v0.2.45-debian12-x86_64/seine --version

The expected output is: seine v0.2.45

When starting mining, use the new executable path shown above with your
existing address/pool options. For a notebook, use --ui plain and supply
--address and --pool-url explicitly. Stop any previous miner before starting
another instance.

The archive extracts to a versioned folder, so an older executable can remain
available separately. No wallet address or miner configuration is bundled.

Updating this compatibility build
--------------------------------
Keep --auto-update off, and avoid --self-update on Debian 12. Those options
download the standard upstream Linux x86_64 release, without checking glibc
compatibility. The official v0.2.45 binary requires GLIBC_2.39. Future updates
for this machine should also be built against Debian 12 or another compatible
glibc baseline. Automatic updating is off by default.

Features and validation
-----------------------
NVIDIA operation requires compatible drivers and the NVRTC runtime, as with
the upstream Linux release. GPU operation was not tested here.

The binary was built with upstream's pinned Rust 1.93.0 and Cargo.lock.
No native-CPU compiler flags were added. See BUILD-INFO.txt for the build
settings, required glibc version, and completed checks.

The upstream license, privacy policy, and README are included.
SHA256SUMS.txt contains checksums for the extracted files.
