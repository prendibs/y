# vltrig 6.26.0.6 for Android Termux (ARM64)

Locally built from https://github.com/HashVault/vltrig at commit
`b6d2ea5a48dfd7579f179a120de7dadacd46adbc`. This is a custom build, not an
official HashVault release. It targets Android 7+ (API 24), ARM64 (`aarch64`),
and native Termux installed at `/data/data/com.termux`.

## Install

Download `vltrig-6.26.0.6-termux-arm64.tar.gz` to the phone's Download folder.
In Termux, run:

```sh
uname -m
pkg update
pkg install -y libuv openssl libnghttp2 tar
termux-setup-storage
cd "$HOME"
tar -xzf "$HOME/storage/downloads/vltrig-6.26.0.6-termux-arm64.tar.gz"
cd vltrig-6.26.0.6-termux-arm64
chmod +x vltrig
./vltrig --version
```

`uname -m` must report `aarch64`. Grant Android's storage permission when
`termux-setup-storage` requests it. Keep the executable under Termux's home
directory: Android shared storage does not allow direct execution.
Termux's package manager also installs the transitive runtime dependencies,
including CA certificates, zlib, and libandroid-spawn.

## Run

Replace `YOUR_MONERO_WALLET` with your public Monero receiving address:

```sh
./vltrig -u YOUR_MONERO_WALLET -p termux \
  -t 1 --randomx-mode=light --no-huge-pages
```

This uses the built-in HashVault primary and backup pools, their upstream
TLS certificate pin, and DNS-over-HTTPS defaults. Omitting `-o` preserves
those default pools. Stop with `Ctrl+C`.

The initial profile uses one CPU thread and RandomX light mode, which uses
roughly 256 MiB for its cache plus other application memory. Light mode is
slower; fast mode requires more than 2 GiB for its dataset plus other memory.
Choose thread count and mode according to the phone's available RAM and
sustained thermal performance.
The upstream developer donation remains unchanged.

To check configuration without starting mining, add `--dry-run` to the
command above. `--help` lists the available options.

## Rebuild on the phone

The complete patched source is included in `source/`:

```sh
cd source
bash scripts/build-termux.sh
./build-termux/vltrig --version
```

The script installs Clang, CMake, Ninja, pkg-config, and the development
libraries, then builds with two compiler jobs. Use
`VLTRIG_BUILD_JOBS=1 bash scripts/build-termux.sh` if build memory is limited.
It does not start mining. See `source/doc/TERMUX.md` for details.

## Features and verification

RandomX ARM64 JIT, TLS, HTTP/2 DNS-over-HTTPS, and HashVault defaults are
enabled. GPU backends, hwloc, MSR access, and DMI are disabled. Root is not
required. C++ runtime support is linked into the executable; networking and
TLS libraries are supplied by Termux.

The executable was cross-compiled with Android NDK r27c / Clang 18.0.3.
ELF inspection verifies ARM64, Android's `/system/bin/linker64`, the Termux
library path, and 16 KiB load-segment alignment. See `BUILD-INFO.txt` for
the exact build configuration, checks, and testing limits.

## Files

- `vltrig`: Android ARM64 executable.
- `source/`: corresponding patched source with native Termux build script.
- `BUILD-INFO.txt`: provenance, dependency versions, and verification results.
- `termux-dependencies.json`: official package URLs and SHA-256 hashes used
  for cross-compilation. Install runtime updates through Termux's `pkg`.
- `SHA256SUMS`: checksums for packaged files.
- `LICENSE` and `licenses/`: upstream and bundled runtime license notices.

If the Android loader reports a missing `libuv.so`, `libssl.so.3`,
`libcrypto.so.3`, or `libnghttp2.so`, rerun the runtime package installation
above. For a Termux fork with a different app package path, build from source
inside that app so the compiler uses its own prefix.
