#!/usr/bin/env bash
set -euo pipefail
task_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
work_dir="$task_root/build-work"
python3 "$task_root/build-support/fetch-deps.py"
ndk_dir="${VLTRIG_ANDROID_NDK:?Set VLTRIG_ANDROID_NDK to your Android NDK r27c directory}"
stage_dir="$work_dir/termux-sysroot"
termux_prefix="$stage_dir/data/data/com.termux/files/usr"
mkdir -p "$stage_dir"
for package in "$work_dir"/termux-debs/*.deb; do
    dpkg-deb --extract "$package" "$stage_dir"
done
cmake -S "$task_root/source" -B "$work_dir/build-android-arm64" -G Ninja \
    -DCMAKE_TOOLCHAIN_FILE="$ndk_dir/build/cmake/android.toolchain.cmake" \
    -DANDROID_ABI=arm64-v8a \
    -DANDROID_PLATFORM=android-24 \
    -DANDROID_STL=c++_static \
    -DANDROID_SUPPORT_FLEXIBLE_PAGE_SIZES=ON \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_SKIP_RPATH=ON \
    -DCMAKE_EXE_LINKER_FLAGS="-Wl,-z,max-page-size=16384 -Wl,-rpath,/data/data/com.termux/files/usr/lib -Wl,-rpath-link,$termux_prefix/lib" \
    -DUV_INCLUDE_DIR="$termux_prefix/include" \
    -DUV_LIBRARY="$termux_prefix/lib/libuv.so" \
    -DOPENSSL_INCLUDE_DIR="$termux_prefix/include" \
    -DOPENSSL_SSL_LIBRARY="$termux_prefix/lib/libssl.so" \
    -DOPENSSL_CRYPTO_LIBRARY="$termux_prefix/lib/libcrypto.so" \
    -DNGHTTP2_INCLUDE_DIR="$termux_prefix/include" \
    -DNGHTTP2_LIBRARY="$termux_prefix/lib/libnghttp2.so" \
    -DWITH_HWLOC=OFF \
    -DWITH_OPENCL=OFF \
    -DWITH_CUDA=OFF \
    -DWITH_MSR=OFF \
    -DWITH_DMI=OFF \
    -DWITH_TLS=ON \
    -DWITH_HTTP2=ON \
    -DWITH_SECURE_JIT=ON
cmake --build "$work_dir/build-android-arm64" --parallel 6
