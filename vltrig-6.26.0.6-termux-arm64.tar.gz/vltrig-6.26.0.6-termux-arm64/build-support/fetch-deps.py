#!/usr/bin/env python3
from pathlib import Path
import hashlib
import json
import urllib.request

root = Path(__file__).resolve().parent.parent
dest = root / 'build-work/termux-debs'
dest.mkdir(parents=True, exist_ok=True)
for item in json.loads((root / 'termux-dependencies.json').read_text()):
    target = dest / item['filename']
    data = target.read_bytes() if target.exists() else urllib.request.urlopen(item['url']).read()
    if hashlib.sha256(data).hexdigest() != item['sha256']:
        raise SystemExit('Checksum mismatch: ' + item['package'])
    target.write_bytes(data)
    print(item['package'], item['version'])
