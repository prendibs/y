#include "3rdparty/fmt/format.h"
#include <cstdio>
#include <string>

alignas(64) thread_local volatile int test_marker = 0;

int main() {
    test_marker = 1;
    const auto message = fmt::format("{}: {} threads, {:.1f}", "Termux", 2, 2.5);
    if (message != "Termux: 2 threads, 2.5") {
        return 1;
    }
    std::puts(message.c_str());
    return 0;
}
