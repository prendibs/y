# Android Termux (ARM64)

This build targets native `aarch64` Termux on Android 7 or newer. It keeps
RandomX, TLS, and HTTP/2 DNS-over-HTTPS support. The CPU backend is enabled;
OpenCL, CUDA, hwloc, MSR, and DMI support are disabled. Root is not required.

## Build on the device

Keep the supplied source folder under Termux's home directory, for example
`~/vltrig`. Android shared storage such as `/sdcard` does not support running
the resulting executable directly.

From the supplied source folder, run:

```sh
uname -m                 # Must print aarch64
pkg update
bash scripts/build-termux.sh
```

The script installs its build dependencies with `pkg`, then builds
`build-termux/vltrig` and prints its version. It does not start mining.
The script is included with this source package; it is not assumed to be
present in the upstream HashVault repository.

Builds use two compiler jobs by default. To change the number or output
directory:

```sh
VLTRIG_BUILD_JOBS=1 VLTRIG_BUILD_DIR="$HOME/vltrig-build" \
  bash scripts/build-termux.sh
```

The native dependencies are `clang`, `cmake`, `ninja`, `pkg-config`, `libuv`,
`openssl`, and `libnghttp2`. The script uses Termux's `$PREFIX` and compilers;
an Android NDK is not needed for a native build.

## Verify and run

Check the executable without connecting to a pool:

```sh
./build-termux/vltrig --version
./build-termux/vltrig --help
```

Replace `YOUR_MONERO_WALLET` with your Monero wallet address. This example
starts with one thread and RandomX light mode to limit memory use:

```sh
./build-termux/vltrig \
  -u YOUR_MONERO_WALLET -p termux \
  -t 1 --randomx-mode=light --no-huge-pages
```

Omitting `-o` preserves the upstream HashVault primary and backup pools,
their TLS certificate pin, and DNS-over-HTTPS defaults.

Stop with `Ctrl+C`. Light mode is slower than fast mode but uses much less
memory. Fast mode needs more than 2 GiB for its dataset, in addition to the
rest of the application's memory. Increase threads or switch modes only as
appropriate for the device.

## Build notes

`ANDROID=ON` selects the project's Android code paths. Do not replace it with
`CMAKE_SYSTEM_NAME=Android` for a native Termux build: that asks CMake to
discover a separate Android toolchain.

Android Bionic provides pthread and realtime functions through libc. The
Android branch in `CMakeLists.txt` therefore links `dl` and `log`, without
requiring separate `pthread` or `rt` libraries.

`WITH_SECURE_JIT=ON` makes the ARM64 RandomX JIT switch its code memory between
writable and executable permissions. ARM64 JIT support remains enabled.

The bundled fmt header uses its own string view in this C++11 build instead
of libc++'s pre-C++17 extension. This avoids the removed generic
`std::char_traits` specialization in recent Termux C++ libraries.

For a cross-built executable, install the runtime libraries listed in its
package README before running it. A successful cross-build and ELF inspection
do not replace testing on the Android device.
