#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

# Build on the Android device inside a native ARM64 Termux session.
if [[ -z "${PREFIX:-}" ]] || ! command -v pkg >/dev/null 2>&1; then
    printf '%s\n' 'Run this script inside native Termux on Android.' >&2
    exit 1
fi

if [[ "$(uname -m)" != 'aarch64' ]]; then
    printf '%s\n' 'This build script targets aarch64 (64-bit ARM) Termux.' >&2
    exit 1
fi

source_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd -P)"
build_dir="${VLTRIG_BUILD_DIR:-${source_dir}/build-termux}"
build_jobs="${VLTRIG_BUILD_JOBS:-2}"

if [[ ! "$build_jobs" =~ ^[1-9][0-9]*$ ]]; then
    printf '%s\n' 'VLTRIG_BUILD_JOBS must be a positive integer.' >&2
    exit 1
fi

pkg install -y clang cmake ninja pkg-config libuv openssl libnghttp2

# ANDROID selects vltrig's Android platform code without making CMake search
# for an NDK. Termux already provides native Android compilers and libraries.
cmake -S "$source_dir" -B "$build_dir" -G Ninja \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_C_COMPILER=clang \
    -DCMAKE_CXX_COMPILER=clang++ \
    -DCMAKE_PREFIX_PATH="$PREFIX" \
    -DXMRIG_DEPS="$PREFIX" \
    -DOPENSSL_ROOT_DIR="$PREFIX" \
    -DANDROID=ON \
    -DARM_V8=ON \
    -DWITH_HWLOC=OFF \
    -DWITH_OPENCL=OFF \
    -DWITH_CUDA=OFF \
    -DWITH_MSR=OFF \
    -DWITH_DMI=OFF \
    -DWITH_TLS=ON \
    -DWITH_HTTP2=ON \
    -DWITH_SECURE_JIT=ON \
    "$@"

cmake --build "$build_dir" --parallel "$build_jobs"
"$build_dir/vltrig" --version

printf '\nBuilt: %s/vltrig\n' "$build_dir"
printf '%s\n' 'Build complete. Mining has not been started.'
